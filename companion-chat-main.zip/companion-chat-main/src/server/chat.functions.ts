import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const InputSchema = z.object({
  messages: z.array(
    z.object({
      role: z.enum(["user", "assistant"]),
      content: z.string(),
    })
  ),
});

export const chatWithGif = createServerFn({ method: "POST" })
  .inputValidator((data) => InputSchema.parse(data))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content:
              "You are a friendly, witty AI companion. Always answer the user's question clearly and concisely (2-4 sentences). Then ALWAYS call the reply_with_gif tool with your answer and a short 1-3 word gifKeyword that captures the emotion or topic of the answer (e.g. 'happy dance', 'thinking', 'mind blown', 'cat coding').",
          },
          ...data.messages,
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "reply_with_gif",
              description: "Reply to the user with text answer and a GIF search keyword.",
              parameters: {
                type: "object",
                properties: {
                  answer: { type: "string", description: "The textual answer to the user." },
                  gifKeyword: {
                    type: "string",
                    description: "1-3 word keyword for fetching a relevant reaction GIF.",
                  },
                },
                required: ["answer", "gifKeyword"],
                additionalProperties: false,
              },
            },
          },
        ],
        tool_choice: { type: "function", function: { name: "reply_with_gif" } },
      }),
    });

    if (!response.ok) {
      if (response.status === 429) throw new Error("Rate limit exceeded. Try again shortly.");
      if (response.status === 402) throw new Error("AI credits exhausted. Add credits to continue.");
      const t = await response.text();
      throw new Error(`AI error: ${t}`);
    }

    const json = await response.json();
    const toolCall = json.choices?.[0]?.message?.tool_calls?.[0];
    let answer = json.choices?.[0]?.message?.content ?? "";
    let gifKeyword = "thinking";
    if (toolCall?.function?.arguments) {
      try {
        const args = JSON.parse(toolCall.function.arguments);
        answer = args.answer || answer;
        gifKeyword = args.gifKeyword || gifKeyword;
      } catch {
        /* ignore */
      }
    }

    // Fetch a GIF from Tenor (free public anonymous key)
    let gifUrl: string | null = null;
    try {
      const tenorRes = await fetch(
        `https://g.tenor.com/v1/search?q=${encodeURIComponent(
          gifKeyword
        )}&key=LIVDSRZULELA&limit=15&contentfilter=medium`
      );
      if (tenorRes.ok) {
        const tenorJson = await tenorRes.json();
        const items: any[] = tenorJson.results ?? [];
        if (items.length > 0) {
          const pick = items[Math.floor(Math.random() * items.length)];
          const media = pick.media?.[0];
          gifUrl =
            media?.tinygif?.url ??
            media?.gif?.url ??
            media?.mediumgif?.url ??
            null;
        }
      }
    } catch {
      /* ignore gif errors */
    }

    return { answer, gifKeyword, gifUrl };
  });
