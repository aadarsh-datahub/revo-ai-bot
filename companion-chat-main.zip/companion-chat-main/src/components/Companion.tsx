interface CompanionProps {
  mood: "idle" | "thinking" | "happy";
}

export function Companion({ mood }: CompanionProps) {
  return (
    <div className="relative h-48 w-full overflow-hidden rounded-2xl border border-border/40 bg-gradient-to-b from-companion-sky to-companion-ground shadow-glow">
      {/* Stars */}
      <div className="pointer-events-none absolute inset-0">
        <span className="absolute left-[10%] top-[15%] h-1 w-1 rounded-full bg-white/70 animate-pulse-slow" />
        <span className="absolute left-[30%] top-[8%] h-0.5 w-0.5 rounded-full bg-white/60 animate-pulse-slow" />
        <span className="absolute left-[55%] top-[20%] h-1 w-1 rounded-full bg-white/80 animate-pulse-slow" />
        <span className="absolute left-[78%] top-[10%] h-0.5 w-0.5 rounded-full bg-white/70 animate-pulse-slow" />
        <span className="absolute left-[88%] top-[25%] h-1 w-1 rounded-full bg-white/60 animate-pulse-slow" />
      </div>

      {/* Moon glow */}
      <div className="absolute right-8 top-6 h-12 w-12 rounded-full bg-primary/30 blur-2xl" />
      <div className="absolute right-10 top-8 h-8 w-8 rounded-full bg-primary/80" />

      {/* Mountains */}
      <svg
        className="absolute bottom-12 w-full opacity-60"
        viewBox="0 0 400 80"
        preserveAspectRatio="none"
      >
        <polygon points="0,80 80,30 160,60 240,20 320,55 400,35 400,80" fill="var(--companion-hill)" />
      </svg>

      {/* Ground line */}
      <div className="absolute bottom-12 h-px w-full bg-foreground/10" />

      {/* Walking companion */}
      <div className="absolute bottom-10 left-0 w-full">
        <div className="animate-walk-across">
          <div className={mood === "thinking" ? "animate-bob-fast" : "animate-bob"}>
            <CompanionCharacter mood={mood} />
          </div>
        </div>
      </div>

      {/* Foreground hill */}
      <div className="absolute -bottom-6 left-0 h-16 w-full rounded-[100%] bg-companion-hill" />
    </div>
  );
}

function CompanionCharacter({ mood }: { mood: CompanionProps["mood"] }) {
  return (
    <svg width="56" height="64" viewBox="0 0 56 64" fill="none">
      {/* Shadow */}
      <ellipse cx="28" cy="60" rx="16" ry="2" fill="rgba(0,0,0,0.35)" />
      {/* Body */}
      <rect x="14" y="22" width="28" height="26" rx="10" fill="var(--primary)" />
      {/* Head */}
      <circle cx="28" cy="16" r="12" fill="var(--primary)" />
      {/* Antenna */}
      <line x1="28" y1="4" x2="28" y2="0" stroke="var(--primary-glow)" strokeWidth="1.5" />
      <circle cx="28" cy="-1" r="2" fill="var(--primary-glow)" />
      {/* Eyes */}
      {mood === "happy" ? (
        <>
          <path d="M22 16 q2 -3 4 0" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round" />
          <path d="M30 16 q2 -3 4 0" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round" />
        </>
      ) : (
        <>
          <circle cx="24" cy="16" r="2" fill="white" />
          <circle cx="32" cy="16" r="2" fill="white" />
        </>
      )}
      {/* Mouth */}
      <path d="M24 22 q4 3 8 0" stroke="white" strokeWidth="1.2" fill="none" strokeLinecap="round" />
      {/* Legs (animated) */}
      <rect x="18" y="46" width="6" height="12" rx="2" fill="var(--primary-glow)" className="origin-top animate-leg-left" />
      <rect x="32" y="46" width="6" height="12" rx="2" fill="var(--primary-glow)" className="origin-top animate-leg-right" />
    </svg>
  );
}
