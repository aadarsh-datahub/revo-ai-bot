import { useState, useRef, useEffect } from "react";
import { Send, Sparkles } from "lucide-react";
import { chatWithGif } from "@/server/chat.functions";
import { Companion } from "./Companion";

type Message = {
  role: "user" | "assistant";
  content: string;
  gifUrl?: string | null;
  gifKeyword?: string;
};

export function ChatBox() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hey! I'm Pixel, your walking AI companion. Ask me anything and I'll reply with a GIF reaction!",
      gifKeyword: "wave hello",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    const newUser: Message = { role: "user", content: text };
    const next = [...messages, newUser];
    setMessages(next);
    setInput("");
    setLoading(true);
    try {
      const result = await chatWithGif({
        data: { messages: next.map((m) => ({ role: m.role, content: m.content })) },
      });
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: result.answer,
          gifUrl: result.gifUrl,
          gifKeyword: result.gifKeyword,
        },
      ]);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: `Oops: ${e.message ?? "something went wrong"}` },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const mood: "idle" | "thinking" | "happy" = loading ? "thinking" : "happy";

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-4">
      <Companion mood={mood} />

      <div className="flex flex-col overflow-hidden rounded-2xl border border-border/40 bg-card/60 backdrop-blur-xl shadow-glow">
        <div ref={scrollRef} className="h-[420px] space-y-4 overflow-y-auto p-5">
          {messages.map((m, i) => (
            <MessageBubble key={i} message={m} />
          ))}
          {loading && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Sparkles className="h-4 w-4 animate-pulse text-primary" />
              Pixel is thinking...
            </div>
          )}
        </div>

        <div className="border-t border-border/40 bg-background/40 p-3">
          <div className="flex items-center gap-2 rounded-xl border border-border/50 bg-background/80 px-3 py-2 focus-within:border-primary/60 focus-within:shadow-glow transition">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              placeholder="Ask me anything..."
              className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
              disabled={loading}
            />
            <button
              onClick={send}
              disabled={loading || !input.trim()}
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-primary-glow text-primary-foreground shadow-glow transition hover:scale-105 disabled:opacity-40 disabled:hover:scale-100"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex animate-fade-in ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`max-w-[85%] space-y-2 ${isUser ? "items-end" : "items-start"}`}>
        <div
          className={`rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
            isUser
              ? "bg-gradient-to-br from-primary to-primary-glow text-primary-foreground shadow-glow"
              : "bg-secondary/80 text-foreground"
          }`}
        >
          {message.content}
        </div>
        {message.gifUrl && (
          <div className="overflow-hidden rounded-xl border border-border/40 bg-background/40 shadow-glow">
            <img
              src={message.gifUrl}
              alt={message.gifKeyword ?? "reaction"}
              className="h-auto max-h-56 w-full object-cover"
              loading="lazy"
            />
          </div>
        )}
      </div>
    </div>
  );
}
