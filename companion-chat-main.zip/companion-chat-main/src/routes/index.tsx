import { createFileRoute } from "@tanstack/react-router";
import { ChatBox } from "@/components/ChatBox";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Pixel — AI Companion with GIF Reactions" },
      {
        name: "description",
        content: "Chat with Pixel, a walking AI companion that answers your questions with smart GIF reactions.",
      },
    ],
  }),
});

function Index() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-background">
      {/* Ambient gradient orbs */}
      <div className="pointer-events-none absolute -left-32 top-0 h-96 w-96 rounded-full bg-primary/20 blur-3xl" />
      <div className="pointer-events-none absolute -right-32 bottom-0 h-96 w-96 rounded-full bg-accent-glow/20 blur-3xl" />
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary-glow/10 blur-3xl" />

      <main className="relative z-10 mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-center gap-8 px-4 py-10">
        <header className="text-center">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-border/40 bg-card/40 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
            <span className="h-1.5 w-1.5 rounded-full bg-primary-glow animate-pulse" />
            Powered by Lovable AI
          </div>
          <h1 className="bg-gradient-to-br from-foreground to-muted-foreground bg-clip-text text-4xl font-bold tracking-tight text-transparent sm:text-5xl">
            Meet Pixel
          </h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            Your walking AI companion. Ask anything — get smart answers with reaction GIFs.
          </p>
        </header>

        <ChatBox />
      </main>
    </div>
  );
}
